// Maya David 209282532
// Gaya Zaltsman 209424442

package HW2;

	//new class GradesSheet who has student name and array of his exams
public class GradesSheet {
	private String name;
	private Exam[][] exams;
	
	/**
	 * 
	 * @param name- the name of the student
	 */
	public GradesSheet(String name) { 			// the partial constructor
		this.name=name;
		this.exams= new Exam[8][4];			// new array with 8 exams and 4 quarters
	}
	
	/**
	 * 
	 * @param e - the exam we want to copy
	 */
	public void addOneExam(Exam e) {			// add new exam to the exams array
		int courseNum = e.getCourse() - 1;			// the place in the array should be courseNum-1
		int quarterNum = e.getQuarter() - 1;		// the place in the array should be quarterNum-1
		int grade = e.getGrade();
		
		if (exams[courseNum][quarterNum] == null) {					//check if we have exam in this course and quarter
			exams[courseNum][quarterNum] = new Exam(e);			// add a copy of the exam to the array
		}
		// if we have exam in this course and quarter we need to check the grade
		else if (exams[courseNum][quarterNum].getGrade() < grade) {		// if the new grade is bigger then the old grade
			exams[courseNum][quarterNum].setGrade(grade);						// update the grade of this exam to be the higher
		}
	}
	
	/**
	 * 
	 * @param course- number of the course
	 * @param all - how we want to calculate the mean-full or  relative 
	 * @return  the calculated mean in the course
	 */
	public int calculateMean(int course, boolean all) {
		if(all) {			// if we want the full mean 
			double sum = 0;
			for(int i = 0; i < 4; i++) {					// calculate the mean in this course
				if(exams[course - 1][i].getGrade() != -1) {
					sum += exams[course - 1][i].getGrade();
				}
			}
			return (int) Math.round(sum/4);			// no matter how many exams the student examined always divided by 4
			
		}
		else {
			int numOfExams = 0;
			double sum = 0;			
			for(int i = 0; i < 4; i++) {
				if(exams[course - 1][i].getGrade() != -1) {
					sum += exams[course - 1][i].getGrade();					
					numOfExams++;			//count the number of test the student examined
				}
			}
			
			return (int) Math.round(sum/numOfExams);		// divided by the number of test the student examined
		}	
	}
	
	// print the name of the student and his grade sheets included full and relative means
	public void Print() {
		System.out.println(name);
		for(int i = 0; i < name.length(); i++) {
			System.out.print("*");
		}
		System.out.println("");
		
		// loops to print every exam from the student grade sheet
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 4; j++) {
				if(exams[i][j].getGrade() != -1) { 		// print only the exam the student examined
					exams[i][j].print();
					System.out.print(" | ");
				}
			
			}
			System.out.println("");

			System.out.println("--------------------");
			int fullMean = calculateMean(i + 1, true);			// print the full mean
			int realMean = calculateMean(i + 1, false);			// print the relative mean
			System.out.println(exams[i][0].getCourseName() + " full mean:" + fullMean + ", relative mean:" + realMean);
			System.out.println("--------------------");

		}

	}
	
	
	
	
}
