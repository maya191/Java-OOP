// Maya David 209282532
// Gaya Zaltsman 209424442

package HW2;

// the program get the names and grades of 10 students and print their grade sheets
import java.util.Scanner;

public class hw2_209282532_209424442 {
	
	
	public static void main(String[] args) {
		
		 int numOfCourses=8 ;			// amount of courses
		 int students =10 ;					// amount of students
		 int quarters =4 ;					//  amount of quarters
		
		Scanner input = new Scanner(System.in);
		
		GradesSheet [] allStudents = new GradesSheet[10]; 				// array of all students grades sheets
		
		String[] courseNames = {"Math", "English", "Bible", "History","Literature","Physical education","Science", "Citzenship"};
		
		// Instructions for the user
		System.out.println("Please enter grades. If the student didnt had an exam insert -1");
		
		// loop for the 10 students
		for (int numOfStudent = 0; numOfStudent < students ; numOfStudent++) {
			System.out.println("Please enter student name");
			
			String studentName = input.nextLine();													// get every student name
			GradesSheet gradeSheet1 = new GradesSheet(studentName);			// open new grade sheets for this student
			
			//loop for the courses	
			for (int courseNumber = 1; courseNumber <= numOfCourses; courseNumber++) {
				System.out.println("Please enter the grades of " + courseNames[courseNumber - 1] + ":");
				
				// loop for the quarters
				for (int quarNumber = 1; quarNumber <= quarters ; quarNumber++) {
					System.out.println("For quarter number " + quarNumber);
					int grade = input.nextInt();																// get the grade for specific course and quarter
					Exam e1 = new Exam(courseNumber, quarNumber, grade);			//build new exam 
					gradeSheet1.addOneExam(e1);														// insert the exam to the grade sheet of the student
				}
			}
			allStudents[numOfStudent]=gradeSheet1;												// add grade sheet to the array		
			input.nextLine();		
		}
		for (int i =0 ; i < students ; i++ ) {
			allStudents[i].Print();																					// print the grade sheet of all students
		}
		
	}

}
