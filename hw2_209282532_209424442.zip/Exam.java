// Maya David 209282532
// Gaya Zaltsman 209424442

package HW2;

// new class Exam who has course number, quarter number and grade
public class Exam {
		private int course;
		private int quarter;
		private int grade ;
		
		/**
		 * 
		 * @param course - The course number
		 * @param quarter- The quarter number
		 * @param grade- The grade of the student
		 */
		public Exam(int course, int quarter, int grade) {  		//the full constructor
			this.course=course;
			this.quarter =quarter;
			this.grade=grade;
		}
		
		/**
		 * 
		 * @param other - the exam we want to copy
		 */
		public Exam(Exam other) {			//the copy constructor
			course=other.course;
			quarter =other.quarter;
			grade= other.grade;
		}		
		
		/**
		 * 
		 * @return - the course number of the exam
		 */
		public int getCourse() {			//the course getter method
			return course;
		}
		
		/**
		 * 
		 * @return the quarter number of the exam
		 */
		public int getQuarter() {			//the quarter getter method
			return quarter;
		}
		
		/**
		 * 
		 * @return -the grade of the exam
		 */
		public int getGrade() {			//the grade getter method
			return grade;
		}
		
		/**
		 * 
		 * @param grade - the new grade we want to update
		 */
		public void setGrade(int grade) {			//the grade setter method
			this.grade=grade;
		}
		
		/**
		 * 
		 * @return - the course name who fits the course number
		 */
		public String getCourseName() {			//get the course name who fits the course number
			String[] courseNames = {"Math", "English", "Bible", "History","Literature","Physical education","Science", "Citzenship"};
			return courseNames[course-1];
			
		}
		public void print() {					//print the course name with the quarter and grade of the exam
			String courseName = getCourseName();
			System.out.print(courseName + "(" + quarter + "):" + grade);
		}
		
		
		
}
